<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC <contact@vinades.vn>
 * @Copyright (C) 2020 VINADES.,JSC. All rights reserved
 * @License: Not free read more http://nukeviet.vn/vi/store/modules/nvtools/
 * @Createdate Tue, 10 Nov 2020 06:56:08 GMT
 */

if (!defined('NV_ADMIN')) {
    die('Stop!!!');
}

$submenu['categories'] = $lang_module['categories'];
$submenu['list_categories'] = $lang_module['list_categories'];
$submenu['add_img'] = $lang_module['add_img'];
$submenu['list_img'] = $lang_module['list_img'];
$submenu['config'] = $lang_module['config'];
